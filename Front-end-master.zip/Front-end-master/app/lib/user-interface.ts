interface User {
  username: string,
  email: string,
  tickets_atribuidos: number,
  tickets_fechados: number,
  is_staff: true,
  avg_resolution_time: number
}